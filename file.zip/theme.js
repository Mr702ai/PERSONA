// src/config/theme.js
// Shared colors and tokens so the whole app stays visually consistent.

export const COLORS = {
  gold: '#C9A96E',
  goldDim: '#8A6D3F',
  goldBg: 'rgba(201,169,110,0.08)',
  dark: '#0A0A0C',
  dark2: '#111116',
  dark3: '#18181F',
  dark4: '#22222C',
  border: 'rgba(201,169,110,0.15)',
  borderBright: 'rgba(201,169,110,0.42)',
  text: '#F0EDE8',
  textDim: '#7A7670',
  textMid: '#BDB8B0',
  red: '#E05555',
  green: '#5EC488',
  blue: '#5B9BD5',
  purple: '#9B7FDD',
};
