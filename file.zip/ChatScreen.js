// src/screens/ChatScreen.js
// The core experience: live chat with a voiced persona, live score meters,
// per-message replay, and an End & Analyze button.

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { COLORS } from '../config/theme';
import { getPersonaReply } from '../utils/ai';
import { speak, stopSpeaking } from '../utils/speech';

export default function ChatScreen({ config, voiceOn, onEnd }) {
  const { persona, scenario, difficulty } = config;
  const [messages, setMessages] = useState([]); // {role, content}
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [speakingId, setSpeakingId] = useState(null);
  const [warning, setWarning] = useState('');
  const [meters, setMeters] = useState({ confidence: 50, attraction: 30, calibration: 40 });
  const scrollRef = useRef(null);

  // Opening line
  useEffect(() => {
    const opening = { role: 'assistant', content: persona.opening, id: 'open' };
    setMessages([opening]);
    if (voiceOn) {
      setSpeakingId('open');
      speak(persona.opening, persona, { onDone: () => setSpeakingId(null) });
    }
    return () => stopSpeaking();
  }, []);

  const scrollDown = () => setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 80);

  const send = async () => {
    const text = input.trim();
    if (!text || busy) return;
    setInput('');
    const userMsg = { role: 'user', content: text, id: 'u' + Date.now() };
    const updated = [...messages, userMsg];
    setMessages(updated);
    scrollDown();
    setBusy(true);

    try {
      const reply = await getPersonaReply({
        persona,
        scenario,
        difficulty,
        history: updated.map(({ role, content }) => ({ role, content })),
      });

      const id = 'a' + Date.now();
      const aiMsg = { role: 'assistant', content: reply.text, id };
      setMessages((prev) => [...prev, aiMsg]);
      scrollDown();

      // Update meters
      if (reply.delta) {
        setMeters((prev) => ({
          confidence: clamp(prev.confidence + (reply.delta.confidence || 0)),
          attraction: clamp(prev.attraction + (reply.delta.attraction || 0)),
          calibration: clamp(prev.calibration + (reply.delta.calibration || 0)),
        }));
      }

      // Coaching warning
      if (reply.warning && reply.warning.length > 2) {
        setWarning(reply.warning);
        setTimeout(() => setWarning(''), 5000);
      }

      // Speak it
      if (voiceOn) {
        setSpeakingId(id);
        speak(reply.text, persona, { onDone: () => setSpeakingId(null) });
      }
    } catch (e) {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Connection issue — try again.', id: 'err' + Date.now() },
      ]);
    }
    setBusy(false);
  };

  const replay = (msg) => {
    if (speakingId === msg.id) {
      stopSpeaking();
      setSpeakingId(null);
      return;
    }
    setSpeakingId(msg.id);
    speak(msg.content, persona, { onDone: () => setSpeakingId(null) });
  };

  const endNow = () => {
    stopSpeaking();
    onEnd({ persona, scenario, difficulty, meters, history: messages.map(({ role, content }) => ({ role, content })) });
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: COLORS.dark }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 40 : 0}
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.avatar}>
          <Text style={{ fontSize: 20 }}>{persona.emoji}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.name}>{persona.name}</Text>
          <Text style={styles.sub}>{persona.type}</Text>
        </View>
        {speakingId && <Text style={styles.speakingTag}>● speaking</Text>}
        <TouchableOpacity style={styles.endBtn} onPress={endNow}>
          <Text style={styles.endText}>End & Analyze</Text>
        </TouchableOpacity>
      </View>

      {/* Meters */}
      <View style={styles.meters}>
        <Meter label="Confidence" value={meters.confidence} color={COLORS.gold} />
        <Meter label="Attraction" value={meters.attraction} color={COLORS.red} />
        <Meter label="Calibration" value={meters.calibration} color={COLORS.blue} />
      </View>

      {/* Messages */}
      <ScrollView ref={scrollRef} style={{ flex: 1 }} contentContainerStyle={{ padding: 16, gap: 10 }}>
        {messages.map((m) => (
          <View key={m.id} style={[styles.msgRow, m.role === 'user' && styles.msgRowUser]}>
            <View style={[styles.msgAvatar, m.role === 'user' && styles.msgAvatarUser]}>
              <Text style={m.role === 'user' ? styles.youText : { fontSize: 12 }}>
                {m.role === 'user' ? 'You' : persona.emoji}
              </Text>
            </View>
            <View style={{ maxWidth: '78%' }}>
              <View style={[styles.bubble, m.role === 'user' ? styles.bubbleUser : styles.bubbleAI]}>
                <Text style={styles.bubbleText}>{m.content}</Text>
              </View>
              {m.role === 'assistant' && (
                <TouchableOpacity onPress={() => replay(m)}>
                  <Text style={[styles.replay, speakingId === m.id && { color: COLORS.gold }]}>
                    {speakingId === m.id ? '◼ stop' : '▶ replay'}
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        ))}
        {busy && (
          <View style={styles.msgRow}>
            <View style={styles.msgAvatar}>
              <Text style={{ fontSize: 12 }}>{persona.emoji}</Text>
            </View>
            <View style={[styles.bubble, styles.bubbleAI]}>
              <ActivityIndicator color={COLORS.textDim} size="small" />
            </View>
          </View>
        )}
      </ScrollView>

      {/* Warning */}
      {warning ? (
        <View style={styles.warnBar}>
          <Text style={styles.warnText}>⚠ {warning}</Text>
        </View>
      ) : null}

      {/* Input */}
      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          value={input}
          onChangeText={setInput}
          placeholder="Type your message…"
          placeholderTextColor={COLORS.textDim}
          multiline
        />
        <TouchableOpacity style={styles.sendBtn} onPress={send} disabled={busy}>
          <Text style={styles.sendText}>Send</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

function Meter({ label, value, color }) {
  return (
    <View style={styles.meter}>
      <Text style={styles.meterLabel}>{label}</Text>
      <View style={styles.meterBar}>
        <View style={[styles.meterFill, { width: `${value}%`, backgroundColor: color }]} />
      </View>
      <Text style={[styles.meterVal, { color }]}>{value}</Text>
    </View>
  );
}

const clamp = (n) => Math.max(0, Math.min(100, n));

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', gap: 11, padding: 14,
    borderBottomWidth: 0.5, borderBottomColor: COLORS.border,
  },
  avatar: {
    width: 42, height: 42, borderRadius: 21, backgroundColor: COLORS.dark4,
    alignItems: 'center', justifyContent: 'center',
  },
  name: { color: COLORS.text, fontSize: 14, fontWeight: '700' },
  sub: { color: COLORS.textDim, fontSize: 11 },
  speakingTag: { color: COLORS.gold, fontSize: 10, marginRight: 6 },
  endBtn: { borderWidth: 0.5, borderColor: COLORS.border, borderRadius: 8, paddingVertical: 7, paddingHorizontal: 12 },
  endText: { color: COLORS.textDim, fontSize: 11 },
  meters: {
    flexDirection: 'row', gap: 7, paddingHorizontal: 14, paddingVertical: 10,
    borderBottomWidth: 0.5, borderBottomColor: COLORS.border,
  },
  meter: { flex: 1, backgroundColor: COLORS.dark3, borderRadius: 8, padding: 8, borderWidth: 0.5, borderColor: COLORS.border },
  meterLabel: { color: COLORS.textDim, fontSize: 9, letterSpacing: 1, marginBottom: 5 },
  meterBar: { height: 3, backgroundColor: COLORS.dark4, borderRadius: 2, overflow: 'hidden' },
  meterFill: { height: 3, borderRadius: 2 },
  meterVal: { fontSize: 11, marginTop: 4, fontWeight: '600' },
  msgRow: { flexDirection: 'row', gap: 8, alignItems: 'flex-start' },
  msgRowUser: { flexDirection: 'row-reverse', alignSelf: 'flex-end' },
  msgAvatar: {
    width: 27, height: 27, borderRadius: 14, backgroundColor: COLORS.dark4,
    alignItems: 'center', justifyContent: 'center', marginTop: 2,
  },
  msgAvatarUser: { backgroundColor: 'rgba(201,169,110,0.15)' },
  youText: { color: COLORS.gold, fontSize: 10, fontWeight: '700' },
  bubble: { paddingVertical: 9, paddingHorizontal: 13, borderRadius: 13 },
  bubbleAI: { backgroundColor: COLORS.dark3, borderWidth: 0.5, borderColor: COLORS.border, borderTopLeftRadius: 3 },
  bubbleUser: { backgroundColor: 'rgba(201,169,110,0.09)', borderWidth: 0.5, borderColor: 'rgba(201,169,110,0.25)', borderTopRightRadius: 3 },
  bubbleText: { color: COLORS.text, fontSize: 13.5, lineHeight: 20 },
  replay: { color: COLORS.textDim, fontSize: 11, marginTop: 3, paddingHorizontal: 3 },
  warnBar: {
    backgroundColor: 'rgba(224,85,85,0.09)', borderWidth: 0.5, borderColor: 'rgba(224,85,85,0.22)',
    borderRadius: 8, padding: 8, marginHorizontal: 14, marginBottom: 6,
  },
  warnText: { color: COLORS.red, fontSize: 11 },
  inputRow: {
    flexDirection: 'row', gap: 8, padding: 12, borderTopWidth: 0.5, borderTopColor: COLORS.border,
    alignItems: 'flex-end',
  },
  input: {
    flex: 1, backgroundColor: COLORS.dark3, borderWidth: 0.5, borderColor: COLORS.border,
    borderRadius: 10, paddingHorizontal: 13, paddingVertical: 9, color: COLORS.text,
    fontSize: 13, maxHeight: 110, minHeight: 42,
  },
  sendBtn: { backgroundColor: COLORS.gold, borderRadius: 10, paddingVertical: 11, paddingHorizontal: 16 },
  sendText: { color: '#000', fontSize: 12, fontWeight: '700' },
});
