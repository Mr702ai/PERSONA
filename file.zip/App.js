// App.js
// Root of the app. Handles the screen flow:
// Setup -> Chat -> Analysis -> back to Setup.
// Also holds the global Voice On/Off toggle.

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, SafeAreaView, StatusBar } from 'react-native';
import SetupScreen from './src/screens/SetupScreen';
import ChatScreen from './src/screens/ChatScreen';
import AnalysisScreen from './src/screens/AnalysisScreen';
import { COLORS } from './src/config/theme';
import { stopSpeaking } from './src/utils/speech';

export default function App() {
  const [screen, setScreen] = useState('setup'); // setup | chat | analysis
  const [config, setConfig] = useState(null);
  const [session, setSession] = useState(null);
  const [voiceOn, setVoiceOn] = useState(true);

  const startChat = (cfg) => {
    setConfig(cfg);
    setScreen('chat');
  };

  const endChat = (sess) => {
    setSession(sess);
    setScreen('analysis');
  };

  const resetToSetup = () => {
    stopSpeaking();
    setScreen('setup');
  };

  const toggleVoice = () => {
    if (voiceOn) stopSpeaking();
    setVoiceOn(!voiceOn);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" />

      {/* Global voice toggle floats top-right except on setup (setup has its own header) */}
      {screen !== 'setup' && (
        <View style={styles.topBar}>
          <TouchableOpacity
            style={[styles.voiceToggle, voiceOn && styles.voiceToggleOn]}
            onPress={toggleVoice}
          >
            <View style={[styles.dot, { backgroundColor: voiceOn ? COLORS.gold : COLORS.textDim }]} />
            <Text style={[styles.voiceLabel, voiceOn && { color: COLORS.gold }]}>
              {voiceOn ? 'Voice On' : 'Voice Off'}
            </Text>
          </TouchableOpacity>
        </View>
      )}

      {screen === 'setup' && <SetupScreen onStart={startChat} />}
      {screen === 'chat' && <ChatScreen config={config} voiceOn={voiceOn} onEnd={endChat} />}
      {screen === 'analysis' && <AnalysisScreen session={session} onDone={resetToSetup} />}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.dark },
  topBar: { flexDirection: 'row', justifyContent: 'flex-end', paddingHorizontal: 14, paddingTop: 8 },
  voiceToggle: {
    flexDirection: 'row', alignItems: 'center', gap: 7,
    backgroundColor: COLORS.dark3, borderWidth: 0.5, borderColor: COLORS.border,
    borderRadius: 20, paddingVertical: 5, paddingHorizontal: 13,
  },
  voiceToggleOn: { borderColor: COLORS.gold, backgroundColor: COLORS.goldBg },
  dot: { width: 6, height: 6, borderRadius: 3 },
  voiceLabel: { color: COLORS.textDim, fontSize: 11, fontWeight: '600', letterSpacing: 0.5 },
});
