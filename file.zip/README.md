# SocialOS — Mobile (Expo / React Native)

AI social-intelligence trainer. Practice conversations with voiced AI personas,
get live attraction/confidence/calibration scores, and review a full breakdown
after each session. Sessions are saved on-device.

---

## Setup (do this in order)

### 1. Create the project
```
npx create-expo-app SocialOS
cd SocialOS
```

### 2. Install dependencies
```
npm install expo-speech @react-native-async-storage/async-storage
```

### 3. Drop in these files
Copy everything from this folder into your project, matching the structure below.
Overwrite the default `App.js`.

```
App.js                         <- root, screen flow + voice toggle
src/
  config/
    personas.js                <- 6 personas, voices, scenarios, difficulty
    theme.js                   <- colors
  screens/
    SetupScreen.js             <- pick persona / scenario / difficulty
    ChatScreen.js              <- live voiced chat + score meters
    AnalysisScreen.js          <- post-session rings, flags, tips
  utils/
    ai.js                      <- talks to your backend (EDIT THE URL)
    speech.js                  <- expo-speech wrapper (per-persona voice)
    storage.js                 <- saves sessions on device
backend-example/
    chat.js                    <- deploy this, holds your API key
```

### 4. Stand up the backend (5 min)
The app must NOT contain your Anthropic API key. Deploy `backend-example/chat.js`:
- Easiest: drop it in a Vercel project as `api/chat.js`
- Set an env var `ANTHROPIC_API_KEY` with your key
- Copy the deployed URL

Then open `src/utils/ai.js` and replace:
```js
const API_URL = 'https://YOUR-BACKEND-URL.com';
```
with your real URL (the app calls `${API_URL}/chat`).

### 5. Run it
```
npx expo start
```
Scan the QR code with the **Expo Go** app on your phone.

---

## How it flows
1. **SetupScreen** — choose who you're talking to and how hard it should be.
2. **ChatScreen** — she greets you (and speaks it aloud). You reply; the AI
   stays in character, returns her line plus score deltas, and speaks back in
   her own voice. Tap **▶ replay** on any of her messages to hear it again.
   Toggle **Voice On/Off** any time in the top-right.
3. **End & Analyze** — get scored on Confidence, Attraction, Calibration, and EQ,
   with specific positives, negatives, and improvement tips.
4. Every session is saved on-device (AsyncStorage) for later progress tracking.

## Each persona has her own voice
Voice rate/pitch are tuned per character in `src/config/personas.js`:
- **Sophia** — measured, cool (rate 0.87)
- **Mia** — slow, thoughtful (rate 0.82)
- **Zoe** — fast, bright (rate 1.07)
- **Camille** — flat, guarded (rate 0.77)
- **Arya** — crisp, direct (rate 0.91)
- **Luna** — warm, expressive (rate 0.97)

iOS and Android pick the closest available system voice automatically.

## What to build next (already scaffolded to extend)
- **Progress tab** — read `loadSessions()` from `storage.js`, render averages
- **Text Analyzer** — paste a real convo, same AI call with an analysis prompt
- **Profile AI** — paste a bio, return a grade + rewrite
- **Voice input** — add `@jamsch/expo-speech-recognition` to talk instead of type
