// src/utils/storage.js
// Persistent memory layer. Saves every session to the device so the
// Progress screen can show history and averages across sessions.

import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'socialos_sessions';

export async function loadSessions() {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error('loadSessions error', e);
    return [];
  }
}

export async function saveSession(session) {
  try {
    const sessions = await loadSessions();
    // newest first, cap at 60 stored sessions
    sessions.unshift(session);
    await AsyncStorage.setItem(KEY, JSON.stringify(sessions.slice(0, 60)));
  } catch (e) {
    console.error('saveSession error', e);
  }
}

export async function deleteSession(id) {
  try {
    const sessions = await loadSessions();
    const filtered = sessions.filter((s) => s.id !== id);
    await AsyncStorage.setItem(KEY, JSON.stringify(filtered));
  } catch (e) {
    console.error('deleteSession error', e);
  }
}

// Average a given score field across all stored sessions.
export function averageScore(sessions, field) {
  if (!sessions.length) return 0;
  const sum = sessions.reduce((acc, s) => acc + (s.scores?.[field] || 0), 0);
  return Math.round(sum / sessions.length);
}
