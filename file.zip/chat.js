// backend-example/chat.js
//
// WHY YOU NEED THIS:
// Never put your Anthropic API key inside the mobile app — anyone can extract it.
// Instead, deploy this tiny function (Vercel, Netlify, Cloudflare Workers, or any
// Node server) and point API_URL in src/utils/ai.js at it.
//
// This example is written for Vercel / Next.js API routes, but the logic is the
// same anywhere: receive {system, messages}, forward to Anthropic, return the text.

export default async function handler(req, res) {
  // Allow your app to call this
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });

  const { system, messages } = req.body;

  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY, // set this in your host's env vars
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system,
        messages,
      }),
    });

    const data = await r.json();
    const text = data?.content?.[0]?.text || '';
    return res.status(200).json({ text });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'AI request failed' });
  }
}
