// src/screens/AnalysisScreen.js
// Shown after a session ends. Fetches AI analysis, renders score rings,
// positives/negatives, and suggestions, then saves the session to storage.

import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { COLORS } from '../config/theme';
import { getAnalysis } from '../utils/ai';
import { saveSession } from '../utils/storage';

const RING_COLORS = {
  confidence: COLORS.gold,
  attraction: COLORS.red,
  calibration: COLORS.blue,
  emotional_intelligence: COLORS.green,
};
const RING_LABELS = {
  confidence: 'Confidence',
  attraction: 'Attraction',
  calibration: 'Calibration',
  emotional_intelligence: 'EQ',
};

export default function AnalysisScreen({ session, onDone }) {
  const { persona, scenario, difficulty, meters, history } = session;
  const [loading, setLoading] = useState(true);
  const [analysis, setAnalysis] = useState(null);

  useEffect(() => {
    (async () => {
      let result = await getAnalysis({ persona, scenario, difficulty, history });
      if (!result) {
        // fallback to live meters if the API fails
        result = {
          headline: 'Session Complete',
          scores: {
            confidence: meters.confidence,
            attraction: meters.attraction,
            calibration: meters.calibration,
            emotional_intelligence: Math.round((meters.confidence + meters.calibration) / 2),
          },
          positives: ['Completed the simulation'],
          negatives: ['Detailed analysis unavailable'],
          suggestions: ['Slow your pacing', 'Ask fewer questions', 'Use more storytelling'],
        };
      }
      setAnalysis(result);
      setLoading(false);

      // persist
      await saveSession({
        id: Date.now().toString(),
        persona: persona.name,
        emoji: persona.emoji,
        type: persona.type,
        scenario,
        difficulty,
        headline: result.headline,
        scores: result.scores,
        date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      });
    })();
  }, []);

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator color={COLORS.gold} />
        <Text style={styles.loadingText}>Analyzing your conversation…</Text>
      </View>
    );
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: COLORS.dark }} contentContainerStyle={{ padding: 18, paddingBottom: 40 }}>
      <Text style={styles.title}>{analysis.headline}</Text>
      <Text style={styles.subtitle}>{`${persona.name} · ${scenario} · ${difficulty}`}</Text>

      {/* Rings */}
      <View style={styles.rings}>
        {Object.entries(analysis.scores || {}).map(([k, v]) => (
          <Ring key={k} label={RING_LABELS[k] || k} value={Math.round(v)} color={RING_COLORS[k] || COLORS.gold} />
        ))}
      </View>

      {/* Flags */}
      {(analysis.positives || []).map((t, i) => (
        <View key={'p' + i} style={[styles.flag, styles.flagPos]}>
          <Text style={styles.flagIcon}>✓</Text>
          <Text style={styles.flagText}>{t}</Text>
        </View>
      ))}
      {(analysis.negatives || []).map((t, i) => (
        <View key={'n' + i} style={[styles.flag, styles.flagNeg]}>
          <Text style={styles.flagIcon}>✗</Text>
          <Text style={styles.flagText}>{t}</Text>
        </View>
      ))}

      {/* Suggestions */}
      <View style={styles.box}>
        <Text style={styles.boxTitle}>↑ Key improvements for next time</Text>
        {(analysis.suggestions || []).map((s, i) => (
          <View key={i} style={styles.suggRow}>
            <Text style={styles.suggNum}>{i + 1}.</Text>
            <Text style={styles.suggText}>{s}</Text>
          </View>
        ))}
      </View>

      <TouchableOpacity style={styles.btn} onPress={onDone}>
        <Text style={styles.btnText}>New Scenario</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function Ring({ label, value, color }) {
  // Lightweight ring using nested circular Views (no svg dependency).
  return (
    <View style={styles.ringWrap}>
      <View style={[styles.ringOuter, { borderColor: COLORS.dark4 }]}>
        <View style={[styles.ringInner, { borderColor: color, borderTopColor: value > 75 ? color : 'transparent', borderRightColor: value > 50 ? color : 'transparent', borderBottomColor: value > 25 ? color : 'transparent', borderLeftColor: value > 0 ? color : 'transparent' }]}>
          <Text style={[styles.ringValue, { color }]}>{value}</Text>
        </View>
      </View>
      <Text style={styles.ringLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  loading: { flex: 1, backgroundColor: COLORS.dark, alignItems: 'center', justifyContent: 'center', gap: 12 },
  loadingText: { color: COLORS.textDim, fontSize: 12 },
  title: { color: COLORS.text, fontSize: 26, fontWeight: '800', textAlign: 'center', marginBottom: 5, marginTop: 10 },
  subtitle: { color: COLORS.textDim, fontSize: 12, textAlign: 'center', marginBottom: 24 },
  rings: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 18, marginBottom: 22 },
  ringWrap: { alignItems: 'center' },
  ringOuter: {
    width: 72, height: 72, borderRadius: 36, borderWidth: 6,
    alignItems: 'center', justifyContent: 'center', marginBottom: 6,
  },
  ringInner: {
    width: 72, height: 72, borderRadius: 36, borderWidth: 6, position: 'absolute',
    alignItems: 'center', justifyContent: 'center', transform: [{ rotate: '-45deg' }],
  },
  ringValue: { fontSize: 17, fontWeight: '800', transform: [{ rotate: '45deg' }] },
  ringLabel: { color: COLORS.textDim, fontSize: 9, letterSpacing: 1 },
  flag: { flexDirection: 'row', gap: 8, padding: 11, borderRadius: 8, marginBottom: 7, borderWidth: 0.5 },
  flagPos: { backgroundColor: 'rgba(94,196,136,0.07)', borderColor: 'rgba(94,196,136,0.2)' },
  flagNeg: { backgroundColor: 'rgba(224,85,85,0.07)', borderColor: 'rgba(224,85,85,0.2)' },
  flagIcon: { fontSize: 13 },
  flagText: { color: COLORS.text, fontSize: 12, flex: 1, lineHeight: 18 },
  box: { backgroundColor: COLORS.dark3, borderWidth: 0.5, borderColor: COLORS.border, borderRadius: 12, padding: 15, marginVertical: 16 },
  boxTitle: { color: COLORS.gold, fontSize: 12, fontWeight: '700', marginBottom: 10 },
  suggRow: { flexDirection: 'row', gap: 8, marginBottom: 7 },
  suggNum: { color: COLORS.goldDim, fontWeight: '700' },
  suggText: { color: COLORS.textMid, fontSize: 12, flex: 1 },
  btn: { backgroundColor: COLORS.gold, borderRadius: 10, paddingVertical: 13, alignItems: 'center' },
  btnText: { color: '#000', fontSize: 12, fontWeight: '800', letterSpacing: 1 },
});
