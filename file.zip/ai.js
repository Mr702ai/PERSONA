// src/utils/ai.js
// All AI calls go through here. IMPORTANT: never put your API key in the app.
// Point API_URL at your own small backend (a serverless function is perfect)
// that holds the Anthropic key and forwards the request.

const API_URL = 'https://YOUR-BACKEND-URL.com'; // <-- change me

// Get the persona's next reply + live score deltas.
export async function getPersonaReply({ persona, scenario, difficulty, history }) {
  const system = `You are roleplaying as ${persona.name}, a ${persona.type}. Personality: ${persona.style}
Scenario: ${scenario}. Difficulty: ${difficulty}.
Respond ONLY with valid JSON, no markdown:
{"text":"your natural in-character reply","delta":{"confidence":N,"attraction":N,"calibration":N},"warning":""}
delta values are integers from -15 to +15 reflecting how the user's last message landed.
confidence rises with decisiveness/humor, drops with apologies/overexplaining.
attraction rises with wit/teasing, drops with interview questions/desperation.
calibration rises with good pacing and emotional awareness.
warning: empty string, or a short (<=55 char) coaching note if the user made a clear mistake.`;

  const res = await fetch(`${API_URL}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ system, messages: history }),
  });
  const data = await res.json();
  const raw = data.text || '';
  try {
    return JSON.parse(raw.replace(/```json|```/g, '').trim());
  } catch {
    return { text: raw, delta: {}, warning: '' };
  }
}

// Full post-conversation analysis (rings + flags + suggestions).
export async function getAnalysis({ persona, scenario, difficulty, history }) {
  const system = `You are a social intelligence coach. Persona: ${persona.name} (${persona.type}), scenario: ${scenario}, difficulty: ${difficulty}.
Respond ONLY with valid JSON:
{"headline":"2-4 word title","scores":{"confidence":N,"attraction":N,"calibration":N,"emotional_intelligence":N},"positives":["...","..."],"negatives":["...","..."],"suggestions":["...","...","..."]}
Scores 0-100. Be honest and specific, based on the actual conversation.`;

  const transcript = history
    .map((m) => `${m.role === 'assistant' ? persona.name : 'You'}: ${m.content}`)
    .join('\n');

  const res = await fetch(`${API_URL}/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      system,
      messages: [{ role: 'user', content: 'Conversation:\n\n' + transcript }],
    }),
  });
  const data = await res.json();
  const raw = data.text || '{}';
  try {
    return JSON.parse(raw.replace(/```json|```/g, '').trim());
  } catch {
    return null;
  }
}
