// src/utils/speech.js
// Thin wrapper around expo-speech so each persona speaks in her own voice.

import * as Speech from 'expo-speech';

let currentlySpeaking = false;

export function speak(text, persona, { onStart, onDone } = {}) {
  if (!text) return;
  Speech.stop(); // cut off anything currently playing
  currentlySpeaking = true;
  if (onStart) onStart();
  Speech.speak(text, {
    language: 'en-US',
    rate: persona.voice.rate,
    pitch: persona.voice.pitch,
    onDone: () => {
      currentlySpeaking = false;
      if (onDone) onDone();
    },
    onStopped: () => {
      currentlySpeaking = false;
      if (onDone) onDone();
    },
    onError: () => {
      currentlySpeaking = false;
      if (onDone) onDone();
    },
  });
}

export function stopSpeaking() {
  Speech.stop();
  currentlySpeaking = false;
}

export function isSpeaking() {
  return currentlySpeaking;
}
