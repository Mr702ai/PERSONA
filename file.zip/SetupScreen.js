// src/screens/SetupScreen.js
// First screen: pick a persona, scenario, and difficulty, then start.

import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { PERSONAS, SCENARIOS, DIFFICULTY, DIFFICULTY_COLORS } from '../config/personas';
import { COLORS } from '../config/theme';

export default function SetupScreen({ onStart }) {
  const [persona, setPersona] = useState(null);
  const [scenario, setScenario] = useState(null);
  const [difficulty, setDifficulty] = useState(null);

  const ready = persona && scenario && difficulty;

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 18, paddingBottom: 40 }}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.logo}>
          <Text style={styles.logoText}>S</Text>
        </View>
        <Text style={styles.brand}>
          Social<Text style={{ color: COLORS.gold }}>OS</Text>
        </Text>
      </View>

      {/* Personas */}
      <Text style={styles.sectionLabel}>HER PERSONALITY</Text>
      <View style={styles.grid}>
        {Object.values(PERSONAS).map((p) => {
          const selected = persona?.name === p.name;
          return (
            <TouchableOpacity
              key={p.name}
              style={[styles.personaCard, selected && styles.cardSelected]}
              onPress={() => setPersona(p)}
            >
              <Text style={styles.personaEmoji}>{p.emoji}</Text>
              <Text style={styles.personaName}>{p.name}</Text>
              <Text style={styles.personaType}>{p.type}</Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Scenarios */}
      <Text style={styles.sectionLabel}>SCENARIO</Text>
      {SCENARIOS.map((s) => {
        const selected = scenario?.id === s.id;
        return (
          <TouchableOpacity
            key={s.id}
            style={[styles.scenarioCard, selected && styles.cardSelected]}
            onPress={() => setScenario(s)}
          >
            <Text style={styles.scenarioIcon}>{s.icon}</Text>
            <View style={{ flex: 1 }}>
              <Text style={styles.scenarioName}>{s.label}</Text>
              <Text style={styles.scenarioDesc}>{s.desc}</Text>
            </View>
          </TouchableOpacity>
        );
      })}

      {/* Difficulty */}
      <Text style={styles.sectionLabel}>DIFFICULTY</Text>
      <View style={styles.diffRow}>
        {Object.keys(DIFFICULTY).map((d) => {
          const selected = difficulty === d;
          return (
            <TouchableOpacity
              key={d}
              style={[
                styles.diffBtn,
                selected && { backgroundColor: DIFFICULTY_COLORS[d], borderColor: DIFFICULTY_COLORS[d] },
              ]}
              onPress={() => setDifficulty(d)}
            >
              <Text style={[styles.diffText, selected && { color: '#000' }]}>{d}</Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Start */}
      <TouchableOpacity
        style={[styles.startBtn, !ready && styles.startBtnDisabled]}
        disabled={!ready}
        onPress={() => onStart({ persona, scenario: scenario.label, difficulty })}
      >
        <Text style={styles.startText}>Begin Simulation →</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.dark },
  header: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 24, paddingTop: 8 },
  logo: {
    width: 34, height: 34, borderRadius: 8, backgroundColor: COLORS.gold,
    alignItems: 'center', justifyContent: 'center',
  },
  logoText: { color: '#000', fontWeight: '800', fontSize: 16 },
  brand: { color: COLORS.text, fontSize: 18, fontWeight: '700', letterSpacing: 0.5 },
  sectionLabel: {
    color: COLORS.goldDim, fontSize: 11, fontWeight: '600',
    letterSpacing: 1.5, marginBottom: 11, marginTop: 8,
  },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  personaCard: {
    width: '31.5%', backgroundColor: COLORS.dark3, borderWidth: 0.5,
    borderColor: COLORS.border, borderRadius: 10, padding: 12,
  },
  personaEmoji: { fontSize: 20, marginBottom: 6 },
  personaName: { color: COLORS.text, fontSize: 13, fontWeight: '700' },
  personaType: { color: COLORS.goldDim, fontSize: 10, marginTop: 2 },
  scenarioCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: COLORS.dark3, borderWidth: 0.5, borderColor: COLORS.border,
    borderRadius: 10, padding: 13, marginBottom: 8,
  },
  scenarioIcon: { fontSize: 20 },
  scenarioName: { color: COLORS.text, fontSize: 13, fontWeight: '700' },
  scenarioDesc: { color: COLORS.textDim, fontSize: 11, marginTop: 2 },
  cardSelected: { borderColor: COLORS.gold, backgroundColor: COLORS.goldBg },
  diffRow: { flexDirection: 'row', gap: 7, marginBottom: 24 },
  diffBtn: {
    flex: 1, backgroundColor: COLORS.dark3, borderWidth: 0.5, borderColor: COLORS.border,
    borderRadius: 8, paddingVertical: 10, alignItems: 'center',
  },
  diffText: { color: COLORS.textDim, fontSize: 11, fontWeight: '700' },
  startBtn: {
    backgroundColor: COLORS.gold, borderRadius: 10, paddingVertical: 15, alignItems: 'center',
  },
  startBtnDisabled: { opacity: 0.35 },
  startText: { color: '#000', fontSize: 13, fontWeight: '800', letterSpacing: 1 },
});
